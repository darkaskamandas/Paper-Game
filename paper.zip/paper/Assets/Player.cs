﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;
using UnityEngine.UI;

public class Player : MonoBehaviour
{
    [SerializeField] float moveSpeed;
    [SerializeField] float rotationSPeed;

    bool gameover = false;

    Rigidbody2D rb;

    Camera cam;

    public AudioClip audC;
    public AudioSource audS;

    [SerializeField] Text score;

    float cpt = 0f;
    int scr = 0;
    // Start is called before the first frame update
    void Start()
    {
        rb = GetComponent<Rigidbody2D>();
        cam = Camera.main;
    }
    void setScore()
    {
        cpt += Time.deltaTime;
        if (cpt >= .5f)
        {
            cpt = 0f;
            scr++;
            score.text = scr.ToString("000");
        }
    }
    // Update is called once per frame
    void Update()
    {
        if (!gameover)
        {
            setScore();
            if (Input.GetKey(KeyCode.RightArrow))
            {
                transform.Rotate(Vector3.forward * (-rotationSPeed) * Time.deltaTime);
            }
            else if (Input.GetKey(KeyCode.LeftArrow))
            {
                transform.Rotate(Vector3.forward * rotationSPeed * Time.deltaTime);
            }
        }
    }
    void FixedUpdate()
    {
        if (!gameover)
        {
            rb.AddRelativeForce(new Vector3(moveSpeed * Time.fixedDeltaTime, 0f, 0f));
        }
    }
    void LateUpdate()
    {
        if (!gameover)
        {
            cam.transform.position = new Vector3(transform.position.x, transform.position.y, cam.transform.position.z);
        }
    }
    void OnCollisionEnter2D()
    {
        if (!gameover)
        {
            gameover = true;
            GetComponent<SpriteRenderer>().enabled = false;
            GetComponent<PolygonCollider2D>().enabled = false;
            GetComponentInChildren<ParticleSystem>().Play();
            audS.PlayOneShot(audC);
            Invoke("restart", 2f);
        }
    }
    void restart()
    {
        SceneManager.LoadScene(0);
    }
}
